# Smart Library Management System

A complete, database-backed **Smart Library Management System** web application built with Java (embedded HTTP server + H2 SQL database) and a responsive HTML/CSS/JavaScript frontend.

## Modules

1. **Book Management**
   - Add, view, update, and delete book records.
   - Search books by Book ID, title, or author.
   - Filter and display available and unavailable books (`available_copies` / `total_copies`).

2. **Student Management**
   - Register, view, update, and delete student records.
   - Search students by Student ID or name.
   - Stores Student ID, full name, department, and contact number.

3. **Book Issue & Return Management**
   - Issue available books to registered students with issue date, expected return date, and daily fine rate.
   - View all issued, overdue, and returned records.
   - Return books with automatic late-fine calculation and automatic book availability restoration.
   - Update return/due information and recalculate fines.

## Project Structure

- `src/com/library/LibraryServer.java` — HTTP server & REST API endpoints
- `src/com/library/LibraryService.java` — Validation, transactions, fine calculation, and queries
- `src/com/library/Database.java` — H2 SQL schema initialization and default seeding
- `src/com/library/JsonUtil.java` — JSON parser and serializer
- `public/index.html`, `public/styles.css`, `public/app.js` — Responsive login page & 3-module dashboard UI
- `lib/h2-2.3.232.jar` — Embedded H2 SQL database engine
- `data/library.mv.db` — Persistent database file (created automatically on first run)
- `start.bat` / `start.ps1` — One-step compile and run scripts

## How to Run

### Windows PowerShell
```powershell
.\start.ps1
```

### Windows Command Prompt / Explorer
Double-click `start.bat`, or run:
```bat
start.bat
```

Then open **http://127.0.0.1:5050** in your browser.

### Default Login Credentials
- **Username:** `admin`
- **Password:** `admin123`
