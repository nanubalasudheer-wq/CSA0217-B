package com.library;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.SecureRandom;
import java.sql.*;
import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Core business logic and H2 SQL persistence for all three Smart Library modules:
 * 1. Book Management
 * 2. Student Management
 * 3. Book Issue and Return Management
 */
public final class LibraryService {

    public static final class ApiException extends RuntimeException {
        private final int statusCode;

        public ApiException(int statusCode, String message) {
            super(message);
            this.statusCode = statusCode;
        }

        public int getStatusCode() {
            return statusCode;
        }
    }

    private static final Pattern ID_PATTERN = Pattern.compile("^[A-Za-z0-9][A-Za-z0-9_-]{1,39}$");
    private static final Pattern CONTACT_PATTERN = Pattern.compile("^[0-9+\\-\\s()]{7,30}$");
    private static final SecureRandom RANDOM = new SecureRandom();

    private final Database db;

    public LibraryService(Database db) {
        this.db = db;
    }

    // =========================================================================
    // Authentication
    // =========================================================================

    public Map<String, Object> login(String username, String password) throws SQLException {
        String cleanUser = requireNonEmpty(username, "Username is required.", 60);
        String cleanPass = password == null ? "" : password;
        if (cleanPass.isEmpty()) {
            throw new ApiException(400, "Password is required.");
        }

        try (Connection conn = db.getConnection()) {
            String fullName;
            String passwordHash;
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT username, password_hash, full_name FROM users WHERE LOWER(username) = LOWER(?)")) {
                ps.setString(1, cleanUser);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        throw new ApiException(401, "Invalid username or password.");
                    }
                    cleanUser = rs.getString("username");
                    passwordHash = rs.getString("password_hash");
                    fullName = rs.getString("full_name");
                }
            }

            if (!Database.verifyPassword(cleanPass, passwordHash)) {
                throw new ApiException(401, "Invalid username or password.");
            }

            // Purge expired sessions
            try (PreparedStatement clean = conn.prepareStatement(
                    "DELETE FROM sessions WHERE expires_at < CURRENT_TIMESTAMP")) {
                clean.executeUpdate();
            }

            byte[] tokenBytes = new byte[32];
            RANDOM.nextBytes(tokenBytes);
            String token = HexFormat.of().formatHex(tokenBytes);
            Timestamp expiresAt = Timestamp.valueOf(java.time.LocalDateTime.now().plusHours(24));

            try (PreparedStatement insert = conn.prepareStatement(
                    "INSERT INTO sessions (token, username, full_name, expires_at) VALUES (?, ?, ?, ?)")) {
                insert.setString(1, token);
                insert.setString(2, cleanUser);
                insert.setString(3, fullName);
                insert.setTimestamp(4, expiresAt);
                insert.executeUpdate();
            }

            Map<String, Object> result = new LinkedHashMap<>();
            result.put("token", token);
            result.put("username", cleanUser);
            result.put("full_name", fullName);
            return result;
        }
    }

    public Map<String, Object> validateSession(String token) throws SQLException {
        if (token == null || token.isBlank()) {
            throw new ApiException(401, "Authentication required. Please log in.");
        }
        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT username, full_name, expires_at FROM sessions WHERE token = ?")) {
            ps.setString(1, token);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new ApiException(401, "Session expired or invalid. Please log in again.");
                }
                Timestamp expires = rs.getTimestamp("expires_at");
                if (expires.before(new Timestamp(System.currentTimeMillis()))) {
                    logout(token);
                    throw new ApiException(401, "Session expired. Please log in again.");
                }
                Map<String, Object> user = new LinkedHashMap<>();
                user.put("username", rs.getString("username"));
                user.put("full_name", rs.getString("full_name"));
                return user;
            }
        }
    }

    public void logout(String token) throws SQLException {
        if (token == null || token.isBlank()) return;
        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM sessions WHERE token = ?")) {
            ps.setString(1, token);
            ps.executeUpdate();
        }
    }

    // =========================================================================
    // Dashboard Summary Stats
    // =========================================================================

    public Map<String, Object> getStats() throws SQLException {
        try (Connection conn = db.getConnection(); Statement st = conn.createStatement()) {
            Map<String, Object> stats = new LinkedHashMap<>();
            try (ResultSet rs = st.executeQuery("""
                SELECT
                    COUNT(*) AS total_titles,
                    COALESCE(SUM(total_copies), 0) AS total_copies,
                    COALESCE(SUM(available_copies), 0) AS available_copies,
                    COUNT(CASE WHEN available_copies > 0 THEN 1 END) AS available_titles,
                    COUNT(CASE WHEN available_copies = 0 THEN 1 END) AS unavailable_titles
                FROM books
                """)) {
                rs.next();
                stats.put("total_titles", rs.getInt("total_titles"));
                stats.put("total_copies", rs.getInt("total_copies"));
                stats.put("available_copies", rs.getInt("available_copies"));
                stats.put("available_titles", rs.getInt("available_titles"));
                stats.put("unavailable_titles", rs.getInt("unavailable_titles"));
            }

            try (ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM students")) {
                rs.next();
                stats.put("total_students", rs.getInt(1));
            }

            try (ResultSet rs = st.executeQuery("""
                SELECT
                    COUNT(CASE WHEN status = 'ISSUED' THEN 1 END) AS active_issued,
                    COUNT(CASE WHEN status = 'ISSUED' AND due_date < CURRENT_DATE THEN 1 END) AS overdue_count,
                    COUNT(CASE WHEN status = 'RETURNED' THEN 1 END) AS returned_count,
                    COALESCE(SUM(CASE WHEN status = 'RETURNED' THEN fine_amount ELSE 0 END), 0) AS total_fines_collected
                FROM book_issues
                """)) {
                rs.next();
                stats.put("active_issued", rs.getInt("active_issued"));
                stats.put("overdue_count", rs.getInt("overdue_count"));
                stats.put("returned_count", rs.getInt("returned_count"));
                stats.put("total_fines_collected", rs.getBigDecimal("total_fines_collected").setScale(2, RoundingMode.HALF_UP));
            }
            return stats;
        }
    }

    // =========================================================================
    // Module 1: Book Management
    // =========================================================================

    public List<Map<String, Object>> listBooks(String query, String availability) throws SQLException {
        StringBuilder sql = new StringBuilder(
                "SELECT book_id, title, author, category, total_copies, available_copies, created_at FROM books WHERE 1=1");
        List<Object> params = new ArrayList<>();

        if (query != null && !query.isBlank()) {
            String like = "%" + query.trim().toLowerCase(Locale.ROOT) + "%";
            sql.append(" AND (LOWER(book_id) LIKE ? OR LOWER(title) LIKE ? OR LOWER(author) LIKE ?)");
            params.add(like);
            params.add(like);
            params.add(like);
        }

        if ("available".equalsIgnoreCase(availability)) {
            sql.append(" AND available_copies > 0");
        } else if ("unavailable".equalsIgnoreCase(availability)) {
            sql.append(" AND available_copies = 0");
        }

        sql.append(" ORDER BY created_at DESC, book_id ASC");

        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                List<Map<String, Object>> rows = new ArrayList<>();
                while (rs.next()) {
                    rows.add(mapBook(rs));
                }
                return rows;
            }
        }
    }

    public Map<String, Object> addBook(Map<String, Object> body) throws SQLException {
        String bookId = validateId(JsonUtil.getString(body, "book_id"), "Book ID");
        String title = requireNonEmpty(JsonUtil.getString(body, "title"), "Book title is required.", 200);
        String author = requireNonEmpty(JsonUtil.getString(body, "author"), "Author name is required.", 150);
        String category = JsonUtil.getString(body, "category");
        if (category == null || category.isBlank()) {
            category = "General";
        } else if (category.length() > 100) {
            throw new ApiException(400, "Category must be at most 100 characters.");
        }
        Integer totalCopies = JsonUtil.getInt(body, "total_copies");
        if (totalCopies == null || totalCopies < 1 || totalCopies > 10000) {
            throw new ApiException(400, "Total copies must be an integer between 1 and 10,000.");
        }

        try (Connection conn = db.getConnection()) {
            try (PreparedStatement check = conn.prepareStatement("SELECT 1 FROM books WHERE LOWER(book_id) = LOWER(?)")) {
                check.setString(1, bookId);
                try (ResultSet rs = check.executeQuery()) {
                    if (rs.next()) {
                        throw new ApiException(409, "A book with ID '" + bookId + "' already exists.");
                    }
                }
            }

            try (PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO books (book_id, title, author, category, total_copies, available_copies) VALUES (?, ?, ?, ?, ?, ?)")) {
                ps.setString(1, bookId);
                ps.setString(2, title);
                ps.setString(3, author);
                ps.setString(4, category);
                ps.setInt(5, totalCopies);
                ps.setInt(6, totalCopies);
                ps.executeUpdate();
            }

            return getBookById(conn, bookId);
        }
    }

    public Map<String, Object> updateBook(String bookId, Map<String, Object> body) throws SQLException {
        String cleanId = requireNonEmpty(bookId, "Book ID is required.", 40);
        String title = requireNonEmpty(JsonUtil.getString(body, "title"), "Book title is required.", 200);
        String author = requireNonEmpty(JsonUtil.getString(body, "author"), "Author name is required.", 150);
        String category = JsonUtil.getString(body, "category");
        if (category == null || category.isBlank()) {
            category = "General";
        } else if (category.length() > 100) {
            throw new ApiException(400, "Category must be at most 100 characters.");
        }
        Integer newTotalCopies = JsonUtil.getInt(body, "total_copies");
        if (newTotalCopies == null || newTotalCopies < 1 || newTotalCopies > 10000) {
            throw new ApiException(400, "Total copies must be an integer between 1 and 10,000.");
        }

        try (Connection conn = db.getConnection()) {
            conn.setAutoCommit(false);
            try {
                int oldTotal;
                int oldAvailable;
                try (PreparedStatement lock = conn.prepareStatement(
                        "SELECT total_copies, available_copies FROM books WHERE book_id = ? FOR UPDATE")) {
                    lock.setString(1, cleanId);
                    try (ResultSet rs = lock.executeQuery()) {
                        if (!rs.next()) {
                            throw new ApiException(404, "Book '" + cleanId + "' was not found.");
                        }
                        oldTotal = rs.getInt("total_copies");
                        oldAvailable = rs.getInt("available_copies");
                    }
                }

                int currentlyIssued = oldTotal - oldAvailable;
                if (newTotalCopies < currentlyIssued) {
                    throw new ApiException(400,
                            "Total copies (" + newTotalCopies + ") cannot be less than currently issued copies (" + currentlyIssued + ").");
                }
                int newAvailable = newTotalCopies - currentlyIssued;

                try (PreparedStatement ps = conn.prepareStatement(
                        "UPDATE books SET title = ?, author = ?, category = ?, total_copies = ?, available_copies = ? WHERE book_id = ?")) {
                    ps.setString(1, title);
                    ps.setString(2, author);
                    ps.setString(3, category);
                    ps.setInt(4, newTotalCopies);
                    ps.setInt(5, newAvailable);
                    ps.setString(6, cleanId);
                    ps.executeUpdate();
                }

                conn.commit();
                return getBookById(conn, cleanId);
            } catch (SQLException | RuntimeException ex) {
                conn.rollback();
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    public void deleteBook(String bookId) throws SQLException {
        String cleanId = requireNonEmpty(bookId, "Book ID is required.", 40);
        try (Connection conn = db.getConnection()) {
            conn.setAutoCommit(false);
            try {
                try (PreparedStatement exists = conn.prepareStatement(
                        "SELECT 1 FROM books WHERE book_id = ? FOR UPDATE")) {
                    exists.setString(1, cleanId);
                    try (ResultSet rs = exists.executeQuery()) {
                        if (!rs.next()) {
                            throw new ApiException(404, "Book '" + cleanId + "' was not found.");
                        }
                    }
                }

                try (PreparedStatement active = conn.prepareStatement(
                        "SELECT COUNT(*) FROM book_issues WHERE book_id = ? AND status = 'ISSUED'")) {
                    active.setString(1, cleanId);
                    try (ResultSet rs = active.executeQuery()) {
                        rs.next();
                        if (rs.getInt(1) > 0) {
                            throw new ApiException(409,
                                    "Cannot delete book '" + cleanId + "' because copies are currently issued to students. Return them first.");
                        }
                    }
                }

                // Delete closed return history for this book before removing the book record
                try (PreparedStatement delHistory = conn.prepareStatement(
                        "DELETE FROM book_issues WHERE book_id = ? AND status = 'RETURNED'")) {
                    delHistory.setString(1, cleanId);
                    delHistory.executeUpdate();
                }

                try (PreparedStatement delBook = conn.prepareStatement("DELETE FROM books WHERE book_id = ?")) {
                    delBook.setString(1, cleanId);
                    delBook.executeUpdate();
                }

                conn.commit();
            } catch (SQLException | RuntimeException ex) {
                conn.rollback();
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    // =========================================================================
    // Module 2: Student Management
    // =========================================================================

    public List<Map<String, Object>> listStudents(String query) throws SQLException {
        StringBuilder sql = new StringBuilder("""
            SELECT s.student_id, s.name, s.department, s.contact_number, s.created_at,
                   COUNT(CASE WHEN bi.status = 'ISSUED' THEN 1 END) AS active_issues
            FROM students s
            LEFT JOIN book_issues bi ON s.student_id = bi.student_id
            WHERE 1=1
            """);
        List<Object> params = new ArrayList<>();

        if (query != null && !query.isBlank()) {
            String like = "%" + query.trim().toLowerCase(Locale.ROOT) + "%";
            sql.append(" AND (LOWER(s.student_id) LIKE ? OR LOWER(s.name) LIKE ?)");
            params.add(like);
            params.add(like);
        }

        sql.append(" GROUP BY s.student_id, s.name, s.department, s.contact_number, s.created_at");
        sql.append(" ORDER BY s.created_at DESC, s.student_id ASC");

        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                List<Map<String, Object>> rows = new ArrayList<>();
                while (rs.next()) {
                    rows.add(mapStudent(rs));
                }
                return rows;
            }
        }
    }

    public Map<String, Object> addStudent(Map<String, Object> body) throws SQLException {
        String studentId = validateId(JsonUtil.getString(body, "student_id"), "Student ID");
        String name = requireNonEmpty(JsonUtil.getString(body, "name"), "Student name is required.", 150);
        String department = requireNonEmpty(JsonUtil.getString(body, "department"), "Department is required.", 120);
        String contact = validateContact(JsonUtil.getString(body, "contact_number"));

        try (Connection conn = db.getConnection()) {
            try (PreparedStatement check = conn.prepareStatement("SELECT 1 FROM students WHERE LOWER(student_id) = LOWER(?)")) {
                check.setString(1, studentId);
                try (ResultSet rs = check.executeQuery()) {
                    if (rs.next()) {
                        throw new ApiException(409, "A student with ID '" + studentId + "' is already registered.");
                    }
                }
            }

            try (PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO students (student_id, name, department, contact_number) VALUES (?, ?, ?, ?)")) {
                ps.setString(1, studentId);
                ps.setString(2, name);
                ps.setString(3, department);
                ps.setString(4, contact);
                ps.executeUpdate();
            }

            return getStudentById(conn, studentId);
        }
    }

    public Map<String, Object> updateStudent(String studentId, Map<String, Object> body) throws SQLException {
        String cleanId = requireNonEmpty(studentId, "Student ID is required.", 40);
        String name = requireNonEmpty(JsonUtil.getString(body, "name"), "Student name is required.", 150);
        String department = requireNonEmpty(JsonUtil.getString(body, "department"), "Department is required.", 120);
        String contact = validateContact(JsonUtil.getString(body, "contact_number"));

        try (Connection conn = db.getConnection()) {
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE students SET name = ?, department = ?, contact_number = ? WHERE student_id = ?")) {
                ps.setString(1, name);
                ps.setString(2, department);
                ps.setString(3, contact);
                ps.setString(4, cleanId);
                int updated = ps.executeUpdate();
                if (updated == 0) {
                    throw new ApiException(404, "Student '" + cleanId + "' was not found.");
                }
            }
            return getStudentById(conn, cleanId);
        }
    }

    public void deleteStudent(String studentId) throws SQLException {
        String cleanId = requireNonEmpty(studentId, "Student ID is required.", 40);
        try (Connection conn = db.getConnection()) {
            conn.setAutoCommit(false);
            try {
                try (PreparedStatement exists = conn.prepareStatement(
                        "SELECT 1 FROM students WHERE student_id = ? FOR UPDATE")) {
                    exists.setString(1, cleanId);
                    try (ResultSet rs = exists.executeQuery()) {
                        if (!rs.next()) {
                            throw new ApiException(404, "Student '" + cleanId + "' was not found.");
                        }
                    }
                }

                try (PreparedStatement active = conn.prepareStatement(
                        "SELECT COUNT(*) FROM book_issues WHERE student_id = ? AND status = 'ISSUED'")) {
                    active.setString(1, cleanId);
                    try (ResultSet rs = active.executeQuery()) {
                        rs.next();
                        if (rs.getInt(1) > 0) {
                            throw new ApiException(409,
                                    "Cannot delete student '" + cleanId + "' while they have unreturned books.");
                        }
                    }
                }

                try (PreparedStatement delHistory = conn.prepareStatement(
                        "DELETE FROM book_issues WHERE student_id = ? AND status = 'RETURNED'")) {
                    delHistory.setString(1, cleanId);
                    delHistory.executeUpdate();
                }

                try (PreparedStatement delStudent = conn.prepareStatement("DELETE FROM students WHERE student_id = ?")) {
                    delStudent.setString(1, cleanId);
                    delStudent.executeUpdate();
                }

                conn.commit();
            } catch (SQLException | RuntimeException ex) {
                conn.rollback();
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    // =========================================================================
    // Module 3: Book Issue and Return Management
    // =========================================================================

    public List<Map<String, Object>> listIssues(String query, String statusFilter) throws SQLException {
        StringBuilder sql = new StringBuilder("""
            SELECT bi.issue_id, bi.book_id, b.title AS book_title, b.author AS book_author,
                   bi.student_id, s.name AS student_name, s.department AS student_department,
                   bi.issue_date, bi.due_date, bi.return_date, bi.fine_per_day, bi.fine_amount,
                   bi.status, bi.notes
            FROM book_issues bi
            JOIN books b ON bi.book_id = b.book_id
            JOIN students s ON bi.student_id = s.student_id
            WHERE 1=1
            """);
        List<Object> params = new ArrayList<>();

        if (query != null && !query.isBlank()) {
            String like = "%" + query.trim().toLowerCase(Locale.ROOT) + "%";
            sql.append("""
                 AND (LOWER(bi.book_id) LIKE ? OR LOWER(b.title) LIKE ?
                      OR LOWER(bi.student_id) LIKE ? OR LOWER(s.name) LIKE ?)
                """);
            params.add(like);
            params.add(like);
            params.add(like);
            params.add(like);
        }

        if ("issued".equalsIgnoreCase(statusFilter)) {
            sql.append(" AND bi.status = 'ISSUED'");
        } else if ("overdue".equalsIgnoreCase(statusFilter)) {
            sql.append(" AND bi.status = 'ISSUED' AND bi.due_date < CURRENT_DATE");
        } else if ("returned".equalsIgnoreCase(statusFilter)) {
            sql.append(" AND bi.status = 'RETURNED'");
        }

        sql.append(" ORDER BY CASE WHEN bi.status = 'ISSUED' THEN 0 ELSE 1 END, bi.issue_id DESC");

        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                List<Map<String, Object>> rows = new ArrayList<>();
                while (rs.next()) {
                    rows.add(mapIssue(rs));
                }
                return rows;
            }
        }
    }

    public Map<String, Object> issueBook(Map<String, Object> body) throws SQLException {
        String bookId = requireNonEmpty(JsonUtil.getString(body, "book_id"), "Please select a book.", 40);
        String studentId = requireNonEmpty(JsonUtil.getString(body, "student_id"), "Please select a student.", 40);
        LocalDate issueDate = parseDate(JsonUtil.getString(body, "issue_date"), LocalDate.now(), "Issue date");
        LocalDate dueDate = parseDate(JsonUtil.getString(body, "due_date"), issueDate.plusDays(14), "Expected return date");

        if (dueDate.isBefore(issueDate)) {
            throw new ApiException(400, "Expected return date cannot be earlier than the issue date.");
        }

        Double finePerDayRaw = JsonUtil.getDouble(body, "fine_per_day");
        double finePerDay = finePerDayRaw == null ? 2.00 : finePerDayRaw;
        if (finePerDay < 0 || finePerDay > 1000) {
            throw new ApiException(400, "Daily fine rate must be between 0 and 1,000.");
        }
        String notes = trimMax(JsonUtil.getString(body, "notes"), 300);

        try (Connection conn = db.getConnection()) {
            conn.setAutoCommit(false);
            try {
                try (PreparedStatement stCheck = conn.prepareStatement(
                        "SELECT 1 FROM students WHERE student_id = ?")) {
                    stCheck.setString(1, studentId);
                    try (ResultSet rs = stCheck.executeQuery()) {
                        if (!rs.next()) {
                            throw new ApiException(404, "Student '" + studentId + "' is not registered.");
                        }
                    }
                }

                int availableCopies;
                try (PreparedStatement bkLock = conn.prepareStatement(
                        "SELECT available_copies FROM books WHERE book_id = ? FOR UPDATE")) {
                    bkLock.setString(1, bookId);
                    try (ResultSet rs = bkLock.executeQuery()) {
                        if (!rs.next()) {
                            throw new ApiException(404, "Book '" + bookId + "' was not found.");
                        }
                        availableCopies = rs.getInt("available_copies");
                    }
                }

                if (availableCopies <= 0) {
                    throw new ApiException(409, "Book '" + bookId + "' is currently unavailable (0 copies in stock).");
                }

                int newIssueId;
                try (PreparedStatement insert = conn.prepareStatement(
                        """
                        INSERT INTO book_issues (book_id, student_id, issue_date, due_date, return_date, fine_per_day, fine_amount, status, notes)
                        VALUES (?, ?, ?, ?, NULL, ?, 0.00, 'ISSUED', ?)
                        """,
                        Statement.RETURN_GENERATED_KEYS)) {
                    insert.setString(1, bookId);
                    insert.setString(2, studentId);
                    insert.setDate(3, Date.valueOf(issueDate));
                    insert.setDate(4, Date.valueOf(dueDate));
                    insert.setBigDecimal(5, BigDecimal.valueOf(finePerDay).setScale(2, RoundingMode.HALF_UP));
                    insert.setString(6, notes);
                    insert.executeUpdate();
                    try (ResultSet keys = insert.getGeneratedKeys()) {
                        keys.next();
                        newIssueId = keys.getInt(1);
                    }
                }

                try (PreparedStatement dec = conn.prepareStatement(
                        "UPDATE books SET available_copies = available_copies - 1 WHERE book_id = ?")) {
                    dec.setString(1, bookId);
                    dec.executeUpdate();
                }

                conn.commit();
                return getIssueById(conn, newIssueId);
            } catch (SQLException | RuntimeException ex) {
                conn.rollback();
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    public Map<String, Object> returnBook(int issueId, Map<String, Object> body) throws SQLException {
        LocalDate returnDate = parseDate(JsonUtil.getString(body, "return_date"), LocalDate.now(), "Return date");
        String notes = trimMax(JsonUtil.getString(body, "notes"), 300);

        try (Connection conn = db.getConnection()) {
            conn.setAutoCommit(false);
            try {
                String bookId;
                LocalDate issueDate;
                LocalDate dueDate;
                BigDecimal finePerDay;
                String status;
                String existingNotes;

                try (PreparedStatement lock = conn.prepareStatement(
                        "SELECT book_id, issue_date, due_date, fine_per_day, status, notes FROM book_issues WHERE issue_id = ? FOR UPDATE")) {
                    lock.setInt(1, issueId);
                    try (ResultSet rs = lock.executeQuery()) {
                        if (!rs.next()) {
                            throw new ApiException(404, "Issue record #" + issueId + " was not found.");
                        }
                        bookId = rs.getString("book_id");
                        issueDate = rs.getDate("issue_date").toLocalDate();
                        dueDate = rs.getDate("due_date").toLocalDate();
                        finePerDay = rs.getBigDecimal("fine_per_day");
                        status = rs.getString("status");
                        existingNotes = rs.getString("notes");
                    }
                }

                if ("RETURNED".equals(status)) {
                    throw new ApiException(409, "This book has already been returned.");
                }
                if (returnDate.isBefore(issueDate)) {
                    throw new ApiException(400, "Return date cannot be earlier than the issue date (" + issueDate + ").");
                }

                BigDecimal fineAmount = calculateFine(dueDate, returnDate, finePerDay);
                String finalNotes = notes != null ? notes : existingNotes;

                try (PreparedStatement upd = conn.prepareStatement(
                        "UPDATE book_issues SET return_date = ?, fine_amount = ?, status = 'RETURNED', notes = ? WHERE issue_id = ?")) {
                    upd.setDate(1, Date.valueOf(returnDate));
                    upd.setBigDecimal(2, fineAmount);
                    upd.setString(3, finalNotes);
                    upd.setInt(4, issueId);
                    upd.executeUpdate();
                }

                try (PreparedStatement inc = conn.prepareStatement(
                        "UPDATE books SET available_copies = LEAST(total_copies, available_copies + 1) WHERE book_id = ?")) {
                    inc.setString(1, bookId);
                    inc.executeUpdate();
                }

                conn.commit();
                return getIssueById(conn, issueId);
            } catch (SQLException | RuntimeException ex) {
                conn.rollback();
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    public Map<String, Object> updateIssueReturn(int issueId, Map<String, Object> body) throws SQLException {
        try (Connection conn = db.getConnection()) {
            conn.setAutoCommit(false);
            try {
                String bookId;
                LocalDate issueDate;
                LocalDate existingDueDate;
                LocalDate existingReturnDate;
                BigDecimal existingFinePerDay;
                String status;
                String existingNotes;

                try (PreparedStatement lock = conn.prepareStatement(
                        "SELECT book_id, issue_date, due_date, return_date, fine_per_day, status, notes FROM book_issues WHERE issue_id = ? FOR UPDATE")) {
                    lock.setInt(1, issueId);
                    try (ResultSet rs = lock.executeQuery()) {
                        if (!rs.next()) {
                            throw new ApiException(404, "Issue record #" + issueId + " was not found.");
                        }
                        bookId = rs.getString("book_id");
                        issueDate = rs.getDate("issue_date").toLocalDate();
                        existingDueDate = rs.getDate("due_date").toLocalDate();
                        Date rd = rs.getDate("return_date");
                        existingReturnDate = rd == null ? null : rd.toLocalDate();
                        existingFinePerDay = rs.getBigDecimal("fine_per_day");
                        status = rs.getString("status");
                        existingNotes = rs.getString("notes");
                    }
                }

                LocalDate newDueDate = body.containsKey("due_date") && JsonUtil.getString(body, "due_date") != null && !JsonUtil.getString(body, "due_date").isBlank()
                        ? parseDate(JsonUtil.getString(body, "due_date"), existingDueDate, "Expected return date")
                        : existingDueDate;
                if (newDueDate.isBefore(issueDate)) {
                    throw new ApiException(400, "Expected return date cannot be earlier than issue date (" + issueDate + ").");
                }

                Double fineRateDouble = JsonUtil.getDouble(body, "fine_per_day");
                BigDecimal newFinePerDay = fineRateDouble == null
                        ? existingFinePerDay
                        : BigDecimal.valueOf(fineRateDouble).setScale(2, RoundingMode.HALF_UP);
                if (newFinePerDay.compareTo(BigDecimal.ZERO) < 0 || newFinePerDay.compareTo(BigDecimal.valueOf(1000)) > 0) {
                    throw new ApiException(400, "Daily fine rate must be between 0 and 1,000.");
                }

                String rawReturnDate = JsonUtil.getString(body, "return_date");
                LocalDate newReturnDate = existingReturnDate;
                if (rawReturnDate != null && !rawReturnDate.isBlank()) {
                    newReturnDate = parseDate(rawReturnDate, null, "Actual return date");
                    if (newReturnDate.isBefore(issueDate)) {
                        throw new ApiException(400, "Actual return date cannot be earlier than issue date (" + issueDate + ").");
                    }
                }

                String notes = body.containsKey("notes") ? trimMax(JsonUtil.getString(body, "notes"), 300) : existingNotes;

                String newStatus = status;
                BigDecimal newFineAmount = BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);

                boolean transitioningToReturned = "ISSUED".equals(status) && newReturnDate != null;
                if ("RETURNED".equals(status) || transitioningToReturned) {
                    if (newReturnDate == null) {
                        throw new ApiException(400, "Actual return date is required for a returned record.");
                    }
                    newStatus = "RETURNED";
                    Double overrideFine = JsonUtil.getDouble(body, "fine_amount");
                    if (overrideFine != null) {
                        if (overrideFine < 0 || overrideFine > 100000) {
                            throw new ApiException(400, "Fine amount must be between 0 and 100,000.");
                        }
                        newFineAmount = BigDecimal.valueOf(overrideFine).setScale(2, RoundingMode.HALF_UP);
                    } else {
                        newFineAmount = calculateFine(newDueDate, newReturnDate, newFinePerDay);
                    }
                }

                try (PreparedStatement upd = conn.prepareStatement(
                        """
                        UPDATE book_issues
                        SET due_date = ?, return_date = ?, fine_per_day = ?, fine_amount = ?, status = ?, notes = ?
                        WHERE issue_id = ?
                        """)) {
                    upd.setDate(1, Date.valueOf(newDueDate));
                    if (newReturnDate == null) {
                        upd.setNull(2, Types.DATE);
                    } else {
                        upd.setDate(2, Date.valueOf(newReturnDate));
                    }
                    upd.setBigDecimal(3, newFinePerDay);
                    upd.setBigDecimal(4, newFineAmount);
                    upd.setString(5, newStatus);
                    upd.setString(6, notes);
                    upd.setInt(7, issueId);
                    upd.executeUpdate();
                }

                if (transitioningToReturned) {
                    try (PreparedStatement inc = conn.prepareStatement(
                            "UPDATE books SET available_copies = LEAST(total_copies, available_copies + 1) WHERE book_id = ?")) {
                        inc.setString(1, bookId);
                        inc.executeUpdate();
                    }
                }

                conn.commit();
                return getIssueById(conn, issueId);
            } catch (SQLException | RuntimeException ex) {
                conn.rollback();
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    // =========================================================================
    // Helpers & Row Mappers
    // =========================================================================

    private Map<String, Object> getBookById(Connection conn, String bookId) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT book_id, title, author, category, total_copies, available_copies, created_at FROM books WHERE book_id = ?")) {
            ps.setString(1, bookId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new ApiException(404, "Book not found.");
                }
                return mapBook(rs);
            }
        }
    }

    private Map<String, Object> getStudentById(Connection conn, String studentId) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("""
                SELECT s.student_id, s.name, s.department, s.contact_number, s.created_at,
                       COUNT(CASE WHEN bi.status = 'ISSUED' THEN 1 END) AS active_issues
                FROM students s
                LEFT JOIN book_issues bi ON s.student_id = bi.student_id
                WHERE s.student_id = ?
                GROUP BY s.student_id, s.name, s.department, s.contact_number, s.created_at
                """)) {
            ps.setString(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new ApiException(404, "Student not found.");
                }
                return mapStudent(rs);
            }
        }
    }

    private Map<String, Object> getIssueById(Connection conn, int issueId) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("""
                SELECT bi.issue_id, bi.book_id, b.title AS book_title, b.author AS book_author,
                       bi.student_id, s.name AS student_name, s.department AS student_department,
                       bi.issue_date, bi.due_date, bi.return_date, bi.fine_per_day, bi.fine_amount,
                       bi.status, bi.notes
                FROM book_issues bi
                JOIN books b ON bi.book_id = b.book_id
                JOIN students s ON bi.student_id = s.student_id
                WHERE bi.issue_id = ?
                """)) {
            ps.setInt(1, issueId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new ApiException(404, "Issue record not found.");
                }
                return mapIssue(rs);
            }
        }
    }

    private static Map<String, Object> mapBook(ResultSet rs) throws SQLException {
        int total = rs.getInt("total_copies");
        int avail = rs.getInt("available_copies");
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("book_id", rs.getString("book_id"));
        row.put("title", rs.getString("title"));
        row.put("author", rs.getString("author"));
        row.put("category", rs.getString("category"));
        row.put("total_copies", total);
        row.put("available_copies", avail);
        row.put("issued_copies", total - avail);
        row.put("availability", avail > 0 ? "Available" : "Unavailable");
        return row;
    }

    private static Map<String, Object> mapStudent(ResultSet rs) throws SQLException {
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("student_id", rs.getString("student_id"));
        row.put("name", rs.getString("name"));
        row.put("department", rs.getString("department"));
        row.put("contact_number", rs.getString("contact_number"));
        row.put("active_issues", rs.getInt("active_issues"));
        return row;
    }

    private static Map<String, Object> mapIssue(ResultSet rs) throws SQLException {
        LocalDate issueDate = rs.getDate("issue_date").toLocalDate();
        LocalDate dueDate = rs.getDate("due_date").toLocalDate();
        Date retSql = rs.getDate("return_date");
        LocalDate returnDate = retSql == null ? null : retSql.toLocalDate();
        BigDecimal finePerDay = rs.getBigDecimal("fine_per_day").setScale(2, RoundingMode.HALF_UP);
        BigDecimal storedFine = rs.getBigDecimal("fine_amount").setScale(2, RoundingMode.HALF_UP);
        String status = rs.getString("status");

        LocalDate referenceDate = "RETURNED".equals(status) && returnDate != null ? returnDate : LocalDate.now();
        long daysLate = Math.max(0, ChronoUnit.DAYS.between(dueDate, referenceDate));
        boolean isOverdue = "ISSUED".equals(status) && LocalDate.now().isAfter(dueDate);
        BigDecimal estimatedFine = "RETURNED".equals(status)
                ? storedFine
                : calculateFine(dueDate, LocalDate.now(), finePerDay);

        Map<String, Object> row = new LinkedHashMap<>();
        row.put("issue_id", rs.getInt("issue_id"));
        row.put("book_id", rs.getString("book_id"));
        row.put("book_title", rs.getString("book_title"));
        row.put("book_author", rs.getString("book_author"));
        row.put("student_id", rs.getString("student_id"));
        row.put("student_name", rs.getString("student_name"));
        row.put("student_department", rs.getString("student_department"));
        row.put("issue_date", issueDate.toString());
        row.put("due_date", dueDate.toString());
        row.put("return_date", returnDate == null ? null : returnDate.toString());
        row.put("fine_per_day", finePerDay);
        row.put("fine_amount", storedFine);
        row.put("estimated_fine", estimatedFine);
        row.put("days_late", daysLate);
        row.put("is_overdue", isOverdue);
        row.put("status", status);
        row.put("notes", rs.getString("notes"));
        return row;
    }

    private static BigDecimal calculateFine(LocalDate dueDate, LocalDate returnDate, BigDecimal finePerDay) {
        long daysLate = Math.max(0, ChronoUnit.DAYS.between(dueDate, returnDate));
        return finePerDay.multiply(BigDecimal.valueOf(daysLate)).setScale(2, RoundingMode.HALF_UP);
    }

    private static String validateId(String value, String label) {
        String clean = requireNonEmpty(value, label + " is required.", 40);
        if (!ID_PATTERN.matcher(clean).matches()) {
            throw new ApiException(400,
                    label + " must be 2–40 characters (letters, numbers, hyphens, or underscores; start with letter/number).");
        }
        return clean;
    }

    private static String validateContact(String value) {
        String clean = requireNonEmpty(value, "Contact number is required.", 30);
        if (!CONTACT_PATTERN.matcher(clean).matches()) {
            throw new ApiException(400, "Contact number contains invalid characters.");
        }
        long digits = clean.chars().filter(Character::isDigit).count();
        if (digits < 7 || digits > 15) {
            throw new ApiException(400, "Contact number must contain between 7 and 15 digits.");
        }
        return clean;
    }

    private static String requireNonEmpty(String value, String message, int maxLen) {
        if (value == null || value.isBlank()) {
            throw new ApiException(400, message);
        }
        String trimmed = value.trim();
        if (trimmed.length() > maxLen) {
            throw new ApiException(400, "Input exceeds maximum length of " + maxLen + " characters.");
        }
        return trimmed;
    }

    private static String trimMax(String value, int maxLen) {
        if (value == null || value.isBlank()) return null;
        String trimmed = value.trim();
        if (trimmed.length() > maxLen) {
            throw new ApiException(400, "Notes exceed maximum length of " + maxLen + " characters.");
        }
        return trimmed;
    }

    private static LocalDate parseDate(String raw, LocalDate defaultDate, String label) {
        if (raw == null || raw.isBlank()) {
            if (defaultDate != null) return defaultDate;
            throw new ApiException(400, label + " is required.");
        }
        try {
            return LocalDate.parse(raw.trim());
        } catch (Exception e) {
            throw new ApiException(400, label + " must be a valid date (YYYY-MM-DD).");
        }
    }
}
