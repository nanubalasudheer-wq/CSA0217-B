package com.library;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.DosFileAttributeView;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.*;
import java.time.LocalDate;
import java.util.HexFormat;

/**
 * H2 embedded SQL database initialization, connection factory, and seeding.
 */
public final class Database {

    private final String jdbcUrl;
    private final Path dbDir;
    private static final SecureRandom RANDOM = new SecureRandom();

    public Database(String dbFilePath) {
        Path p = Path.of(dbFilePath).toAbsolutePath().normalize();
        this.dbDir = p.getParent();
        ensureWritableDir(this.dbDir);
        this.jdbcUrl = "jdbc:h2:file:" + p + ";AUTO_SERVER=FALSE;DB_CLOSE_DELAY=-1";
    }

    private static void ensureWritableDir(Path dir) {
        if (dir == null) return;
        try {
            Files.createDirectories(dir);
            DosFileAttributeView dos = Files.getFileAttributeView(dir, DosFileAttributeView.class);
            if (dos != null) {
                dos.setReadOnly(false);
            }
        } catch (IOException ignored) {
        }
    }

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(jdbcUrl, "sa", "");
    }

    public void initialize() throws SQLException {
        try (Connection conn = getConnection(); Statement st = conn.createStatement()) {
            st.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(60) NOT NULL UNIQUE,
                    password_hash VARCHAR(200) NOT NULL,
                    full_name VARCHAR(120) NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """);

            st.execute("""
                CREATE TABLE IF NOT EXISTS sessions (
                    token VARCHAR(128) PRIMARY KEY,
                    username VARCHAR(60) NOT NULL,
                    full_name VARCHAR(120) NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP NOT NULL
                )
                """);

            st.execute("""
                CREATE TABLE IF NOT EXISTS books (
                    book_id VARCHAR(40) PRIMARY KEY,
                    title VARCHAR(200) NOT NULL,
                    author VARCHAR(150) NOT NULL,
                    category VARCHAR(100) NOT NULL,
                    total_copies INT NOT NULL CHECK (total_copies >= 1),
                    available_copies INT NOT NULL CHECK (available_copies >= 0),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """);

            st.execute("""
                CREATE TABLE IF NOT EXISTS students (
                    student_id VARCHAR(40) PRIMARY KEY,
                    name VARCHAR(150) NOT NULL,
                    department VARCHAR(120) NOT NULL,
                    contact_number VARCHAR(30) NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """);

            st.execute("""
                CREATE TABLE IF NOT EXISTS book_issues (
                    issue_id INT AUTO_INCREMENT PRIMARY KEY,
                    book_id VARCHAR(40) NOT NULL,
                    student_id VARCHAR(40) NOT NULL,
                    issue_date DATE NOT NULL,
                    due_date DATE NOT NULL,
                    return_date DATE NULL,
                    fine_per_day DECIMAL(10, 2) NOT NULL DEFAULT 2.00,
                    fine_amount DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
                    status VARCHAR(20) NOT NULL,
                    notes VARCHAR(300) NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    CONSTRAINT fk_issue_book FOREIGN KEY (book_id) REFERENCES books(book_id),
                    CONSTRAINT fk_issue_student FOREIGN KEY (student_id) REFERENCES students(student_id)
                )
                """);
        }

        seedDefaults();
    }

    private void seedDefaults() throws SQLException {
        try (Connection conn = getConnection()) {
            if (isTableEmpty(conn, "users")) {
                try (PreparedStatement ps = conn.prepareStatement(
                        "INSERT INTO users (username, password_hash, full_name) VALUES (?, ?, ?)")) {
                    ps.setString(1, "admin");
                    ps.setString(2, hashPassword("admin123"));
                    ps.setString(3, "Head Librarian");
                    ps.executeUpdate();
                }
            }

            if (isTableEmpty(conn, "books") && isTableEmpty(conn, "students") && isTableEmpty(conn, "book_issues")) {
                conn.setAutoCommit(false);
                try {
                    try (PreparedStatement ps = conn.prepareStatement(
                            "INSERT INTO books (book_id, title, author, category, total_copies, available_copies) VALUES (?, ?, ?, ?, ?, ?)")) {
                        insertBook(ps, "BK-101", "Clean Code", "Robert C. Martin", "Software Engineering", 3, 2);
                        insertBook(ps, "BK-102", "Introduction to Algorithms", "Thomas H. Cormen", "Computer Science", 1, 0);
                        insertBook(ps, "BK-103", "Design Patterns", "Erich Gamma", "Software Engineering", 2, 2);
                        insertBook(ps, "BK-104", "Database System Concepts", "Abraham Silberschatz", "Databases", 2, 2);
                        insertBook(ps, "BK-105", "Operating System Concepts", "Greg Gagne", "Systems", 1, 1);
                    }

                    try (PreparedStatement ps = conn.prepareStatement(
                            "INSERT INTO students (student_id, name, department, contact_number) VALUES (?, ?, ?, ?)")) {
                        insertStudent(ps, "STU-2026-001", "Aarav Sharma", "Computer Science", "9876543210");
                        insertStudent(ps, "STU-2026-002", "Priya Nair", "Information Technology", "9845012345");
                        insertStudent(ps, "STU-2026-003", "Rohan Verma", "Electronics", "9731098765");
                        insertStudent(ps, "STU-2026-004", "Meera Iyer", "Data Science", "9611223344");
                    }

                    LocalDate today = LocalDate.now();
                    try (PreparedStatement ps = conn.prepareStatement(
                            "INSERT INTO book_issues (book_id, student_id, issue_date, due_date, return_date, fine_per_day, fine_amount, status, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
                        // Active on-time loan (BK-101 has 2 of 3 available)
                        insertIssue(ps, "BK-101", "STU-2026-001", today.minusDays(3), today.plusDays(11), null, 2.00, 0.00, "ISSUED", "Semester reference copy");
                        // Active overdue loan (BK-102 has 0 of 1 available -> Unavailable)
                        insertIssue(ps, "BK-102", "STU-2026-002", today.minusDays(18), today.minusDays(4), null, 2.00, 0.00, "ISSUED", "Algorithm lab prep");
                        // Returned late record with calculated fine
                        insertIssue(ps, "BK-104", "STU-2026-003", today.minusDays(20), today.minusDays(6), today.minusDays(3), 2.00, 6.00, "RETURNED", "Returned 3 days late; fine settled");
                    }

                    conn.commit();
                } catch (SQLException ex) {
                    conn.rollback();
                    throw ex;
                } finally {
                    conn.setAutoCommit(true);
                }
            }
        }
    }

    private static boolean isTableEmpty(Connection conn, String tableName) throws SQLException {
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM " + tableName)) {
            return rs.next() && rs.getInt(1) == 0;
        }
    }

    private static void insertBook(PreparedStatement ps, String id, String title, String author, String category, int total, int avail) throws SQLException {
        ps.setString(1, id);
        ps.setString(2, title);
        ps.setString(3, author);
        ps.setString(4, category);
        ps.setInt(5, total);
        ps.setInt(6, avail);
        ps.executeUpdate();
    }

    private static void insertStudent(PreparedStatement ps, String id, String name, String dept, String contact) throws SQLException {
        ps.setString(1, id);
        ps.setString(2, name);
        ps.setString(3, dept);
        ps.setString(4, contact);
        ps.executeUpdate();
    }

    private static void insertIssue(PreparedStatement ps, String bookId, String studentId, LocalDate issueDate,
                                    LocalDate dueDate, LocalDate returnDate, double finePerDay, double fineAmount,
                                    String status, String notes) throws SQLException {
        ps.setString(1, bookId);
        ps.setString(2, studentId);
        ps.setDate(3, Date.valueOf(issueDate));
        ps.setDate(4, Date.valueOf(dueDate));
        if (returnDate == null) {
            ps.setNull(5, Types.DATE);
        } else {
            ps.setDate(5, Date.valueOf(returnDate));
        }
        ps.setBigDecimal(6, java.math.BigDecimal.valueOf(finePerDay));
        ps.setBigDecimal(7, java.math.BigDecimal.valueOf(fineAmount));
        ps.setString(8, status);
        ps.setString(9, notes);
        ps.executeUpdate();
    }

    public static String hashPassword(String password) {
        byte[] salt = new byte[16];
        RANDOM.nextBytes(salt);
        String saltHex = HexFormat.of().formatHex(salt);
        return saltHex + ":" + sha256(saltHex + ":" + password);
    }

    public static boolean verifyPassword(String password, String storedHash) {
        if (storedHash == null || !storedHash.contains(":")) return false;
        String[] parts = storedHash.split(":", 2);
        String candidate = sha256(parts[0] + ":" + password);
        return MessageDigest.isEqual(
                candidate.getBytes(StandardCharsets.UTF_8),
                parts[1].getBytes(StandardCharsets.UTF_8));
    }

    private static String sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(input.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }
}
