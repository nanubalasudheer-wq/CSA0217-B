@echo off
setlocal
cd /d "%~dp0"
if not exist out mkdir out
echo Compiling Smart Library Management System...
javac -cp "lib\h2-2.3.232.jar" -d out src\com\library\*.java
if errorlevel 1 (
    echo Compilation failed. Make sure Java JDK is installed and on PATH.
    pause
    exit /b 1
)
echo Starting server at http://127.0.0.1:5050
echo Default login: admin / admin123
start "" "http://127.0.0.1:5050"
java -cp "out;lib\h2-2.3.232.jar" com.library.LibraryServer 5050
pause
