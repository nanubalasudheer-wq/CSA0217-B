package com.library;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.Executors;

/**
 * Embedded HTTP server for the Smart Library Management System.
 * Serves the frontend SPA and REST API endpoints backed by H2 database.
 */
public final class LibraryServer {

    private static final Path PUBLIC_DIR = Path.of("public").toAbsolutePath().normalize();

    public static void main(String[] args) throws Exception {
        int port = 5050;
        String envPort = System.getenv("PORT");
        if (envPort != null && !envPort.isBlank()) {
            port = Integer.parseInt(envPort.trim());
        } else if (args.length > 0) {
            port = Integer.parseInt(args[0].trim());
        }

        String dbPath = Path.of("data", "library").toAbsolutePath().toString();
        Database db = new Database(dbPath);
        db.initialize();

        LibraryService service = new LibraryService(db);

        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 0);
        server.setExecutor(Executors.newVirtualThreadPerTaskExecutor());

        server.createContext("/api/", exchange -> handleApi(exchange, service));
        server.createContext("/", LibraryServer::handleStatic);

        server.start();
        System.out.println("Smart Library Management System running at http://127.0.0.1:" + port);
    }

    private static void handleApi(HttpExchange exchange, LibraryService service) throws IOException {
        String method = exchange.getRequestMethod().toUpperCase(Locale.ROOT);
        String path = exchange.getRequestURI().getPath();
        Map<String, String> query = parseQuery(exchange.getRequestURI().getRawQuery());

        try {
            if ("OPTIONS".equals(method)) {
                sendJson(exchange, 200, Map.of("ok", true));
                return;
            }

            // Public login endpoint
            if ("/api/login".equals(path) && "POST".equals(method)) {
                Map<String, Object> body = readJsonBody(exchange);
                Map<String, Object> session = service.login(
                        JsonUtil.getString(body, "username"),
                        JsonUtil.getString(body, "password"));
                Map<String, Object> res = new LinkedHashMap<>();
                res.put("ok", true);
                res.put("user", session);
                sendJson(exchange, 200, res);
                return;
            }

            // All other /api/* endpoints require valid Bearer token
            String token = extractBearerToken(exchange);
            Map<String, Object> user = service.validateSession(token);

            if ("/api/logout".equals(path) && "POST".equals(method)) {
                service.logout(token);
                sendJson(exchange, 200, Map.of("ok", true));
                return;
            }

            if ("/api/me".equals(path) && "GET".equals(method)) {
                sendJson(exchange, 200, Map.of("ok", true, "user", user));
                return;
            }

            if ("/api/stats".equals(path) && "GET".equals(method)) {
                sendJson(exchange, 200, Map.of("ok", true, "stats", service.getStats()));
                return;
            }

            // Module 1: Books
            if ("/api/books".equals(path)) {
                if ("GET".equals(method)) {
                    List<Map<String, Object>> books = service.listBooks(query.get("q"), query.get("availability"));
                    sendJson(exchange, 200, Map.of("ok", true, "books", books));
                    return;
                }
                if ("POST".equals(method)) {
                    Map<String, Object> created = service.addBook(readJsonBody(exchange));
                    sendJson(exchange, 201, Map.of("ok", true, "book", created, "message", "Book added successfully."));
                    return;
                }
            } else if (path.startsWith("/api/books/")) {
                String bookId = decodeSegment(path.substring("/api/books/".length()));
                if ("PUT".equals(method)) {
                    Map<String, Object> updated = service.updateBook(bookId, readJsonBody(exchange));
                    sendJson(exchange, 200, Map.of("ok", true, "book", updated, "message", "Book updated successfully."));
                    return;
                }
                if ("DELETE".equals(method)) {
                    service.deleteBook(bookId);
                    sendJson(exchange, 200, Map.of("ok", true, "message", "Book deleted successfully."));
                    return;
                }
            }

            // Module 2: Students
            if ("/api/students".equals(path)) {
                if ("GET".equals(method)) {
                    List<Map<String, Object>> students = service.listStudents(query.get("q"));
                    sendJson(exchange, 200, Map.of("ok", true, "students", students));
                    return;
                }
                if ("POST".equals(method)) {
                    Map<String, Object> created = service.addStudent(readJsonBody(exchange));
                    sendJson(exchange, 201, Map.of("ok", true, "student", created, "message", "Student registered successfully."));
                    return;
                }
            } else if (path.startsWith("/api/students/")) {
                String studentId = decodeSegment(path.substring("/api/students/".length()));
                if ("PUT".equals(method)) {
                    Map<String, Object> updated = service.updateStudent(studentId, readJsonBody(exchange));
                    sendJson(exchange, 200, Map.of("ok", true, "student", updated, "message", "Student information updated."));
                    return;
                }
                if ("DELETE".equals(method)) {
                    service.deleteStudent(studentId);
                    sendJson(exchange, 200, Map.of("ok", true, "message", "Student record deleted."));
                    return;
                }
            }

            // Module 3: Book Issue & Return
            if ("/api/issues".equals(path)) {
                if ("GET".equals(method)) {
                    List<Map<String, Object>> issues = service.listIssues(query.get("q"), query.get("status"));
                    sendJson(exchange, 200, Map.of("ok", true, "issues", issues));
                    return;
                }
                if ("POST".equals(method)) {
                    Map<String, Object> created = service.issueBook(readJsonBody(exchange));
                    sendJson(exchange, 201, Map.of("ok", true, "issue", created, "message", "Book issued successfully."));
                    return;
                }
            } else if (path.startsWith("/api/issues/")) {
                String rest = path.substring("/api/issues/".length());
                if (rest.endsWith("/return") && "POST".equals(method)) {
                    String idStr = rest.substring(0, rest.length() - "/return".length());
                    int issueId = parseIntId(idStr);
                    Map<String, Object> returned = service.returnBook(issueId, readJsonBody(exchange));
                    sendJson(exchange, 200, Map.of("ok", true, "issue", returned, "message", "Book returned and availability updated."));
                    return;
                } else if (!rest.contains("/") && "PUT".equals(method)) {
                    int issueId = parseIntId(rest);
                    Map<String, Object> updated = service.updateIssueReturn(issueId, readJsonBody(exchange));
                    sendJson(exchange, 200, Map.of("ok", true, "issue", updated, "message", "Issue/return record updated."));
                    return;
                }
            }

            sendJson(exchange, 404, Map.of("ok", false, "error", "Endpoint not found."));
        } catch (LibraryService.ApiException ex) {
            sendJson(exchange, ex.getStatusCode(), Map.of("ok", false, "error", ex.getMessage()));
        } catch (IllegalArgumentException ex) {
            sendJson(exchange, 400, Map.of("ok", false, "error", ex.getMessage()));
        } catch (SQLException ex) {
            ex.printStackTrace();
            sendJson(exchange, 500, Map.of("ok", false, "error", "Database error: " + ex.getMessage()));
        } catch (Exception ex) {
            ex.printStackTrace();
            sendJson(exchange, 500, Map.of("ok", false, "error", "Internal server error."));
        }
    }

    private static void handleStatic(HttpExchange exchange) throws IOException {
        if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(405, -1);
            exchange.close();
            return;
        }

        String rawPath = exchange.getRequestURI().getPath();
        if (rawPath == null || "/".equals(rawPath) || rawPath.isBlank()) {
            rawPath = "/index.html";
        }

        String rel = rawPath.startsWith("/") ? rawPath.substring(1) : rawPath;
        Path target = PUBLIC_DIR.resolve(rel).normalize();
        if (!target.startsWith(PUBLIC_DIR) || !Files.isRegularFile(target)) {
            target = PUBLIC_DIR.resolve("index.html");
            if (!Files.isRegularFile(target)) {
                byte[] msg = "Not Found".getBytes(StandardCharsets.UTF_8);
                exchange.sendResponseHeaders(404, msg.length);
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(msg);
                }
                return;
            }
        }

        byte[] content = Files.readAllBytes(target);
        Headers headers = exchange.getResponseHeaders();
        headers.set("Content-Type", contentType(target.getFileName().toString()));
        headers.set("Cache-Control", "no-store");
        exchange.sendResponseHeaders(200, content.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(content);
        }
    }

    private static String contentType(String filename) {
        if (filename.endsWith(".html")) return "text/html; charset=utf-8";
        if (filename.endsWith(".css")) return "text/css; charset=utf-8";
        if (filename.endsWith(".js")) return "application/javascript; charset=utf-8";
        if (filename.endsWith(".svg")) return "image/svg+xml";
        if (filename.endsWith(".json")) return "application/json; charset=utf-8";
        return "application/octet-stream";
    }

    private static Map<String, Object> readJsonBody(HttpExchange exchange) throws IOException {
        try (InputStream is = exchange.getRequestBody()) {
            byte[] bytes = is.readAllBytes();
            String body = new String(bytes, StandardCharsets.UTF_8);
            return JsonUtil.parseObject(body);
        }
    }

    private static void sendJson(HttpExchange exchange, int status, Map<String, Object> payload) throws IOException {
        byte[] bytes = JsonUtil.stringify(payload).getBytes(StandardCharsets.UTF_8);
        Headers headers = exchange.getResponseHeaders();
        headers.set("Content-Type", "application/json; charset=utf-8");
        headers.set("Cache-Control", "no-store");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private static String extractBearerToken(HttpExchange exchange) {
        String auth = exchange.getRequestHeaders().getFirst("Authorization");
        if (auth != null && auth.startsWith("Bearer ")) {
            return auth.substring("Bearer ".length()).trim();
        }
        return null;
    }

    private static Map<String, String> parseQuery(String rawQuery) {
        Map<String, String> map = new HashMap<>();
        if (rawQuery == null || rawQuery.isBlank()) return map;
        for (String pair : rawQuery.split("&")) {
            int idx = pair.indexOf('=');
            if (idx > 0) {
                String k = URLDecoder.decode(pair.substring(0, idx), StandardCharsets.UTF_8);
                String v = URLDecoder.decode(pair.substring(idx + 1), StandardCharsets.UTF_8);
                map.put(k, v);
            }
        }
        return map;
    }

    private static String decodeSegment(String seg) {
        if (seg.contains("/")) {
            throw new LibraryService.ApiException(404, "Endpoint not found.");
        }
        return URLDecoder.decode(seg, StandardCharsets.UTF_8);
    }

    private static int parseIntId(String raw) {
        try {
            return Integer.parseInt(raw.trim());
        } catch (NumberFormatException e) {
            throw new LibraryService.ApiException(400, "Invalid record ID.");
        }
    }
}
