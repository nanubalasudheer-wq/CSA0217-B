(() => {
  'use strict';

  const TOKEN_KEY = 'slms_auth_token';

  const state = {
    token: localStorage.getItem(TOKEN_KEY) || '',
    user: null,
    activeModule: 'books',
    books: [],
    students: [],
    issues: [],
    bookFilter: 'all',
    bookQuery: '',
    studentQuery: '',
    issueFilter: 'all',
    issueQuery: '',
    editingBookId: null,
    editingStudentId: null,
    returningIssue: null,
    editingIssue: null,
    pendingDelete: null
  };

  const MODULE_META = {
    books: {
      title: 'Book Management',
      subtitle: 'Add, search, update, and track available or unavailable books'
    },
    students: {
      title: 'Student Management',
      subtitle: 'Register students and manage student profiles and contact details'
    },
    issues: {
      title: 'Book Issue & Return',
      subtitle: 'Issue books, record return dates, calculate late fines, and update availability'
    }
  };

  // Elements
  const loginView = document.getElementById('login-view');
  const appShell = document.getElementById('app-shell');
  const loginForm = document.getElementById('login-form');
  const loginError = document.getElementById('login-error');
  const loginUsername = document.getElementById('login-username');
  const loginPassword = document.getElementById('login-password');
  const togglePasswordBtn = document.getElementById('toggle-password');
  const fillDemoBtn = document.getElementById('fill-demo-btn');
  const logoutBtn = document.getElementById('logout-btn');

  const sidebar = document.getElementById('sidebar');
  const sidebarBackdrop = document.getElementById('sidebar-backdrop');
  const openSidebarBtn = document.getElementById('open-sidebar-btn');
  const closeSidebarBtn = document.getElementById('close-sidebar-btn');

  const moduleTitle = document.getElementById('module-title');
  const moduleSubtitle = document.getElementById('module-subtitle');

  // Helper: Escaping & Dates
  function escapeHtml(val) {
    return String(val ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function todayIso() {
    const d = new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  function addDaysIso(isoDate, days) {
    const [y, m, d] = isoDate.split('-').map(Number);
    const dt = new Date(Date.UTC(y, m - 1, d));
    dt.setUTCDate(dt.getUTCDate() + days);
    return dt.toISOString().slice(0, 10);
  }

  function diffDays(startIso, endIso) {
    if (!startIso || !endIso) return 0;
    const s = Date.parse(startIso + 'T00:00:00Z');
    const e = Date.parse(endIso + 'T00:00:00Z');
    return Math.round((e - s) / 86400000);
  }

  function formatMoney(num) {
    return Number(num || 0).toFixed(2);
  }

  // Toast
  function showToast(message, type = 'success') {
    const container = document.getElementById('toast-container');
    const el = document.createElement('div');
    el.className = `toast toast-${type}`;
    el.innerHTML = `<span>${escapeHtml(message)}</span>`;
    container.appendChild(el);
    setTimeout(() => {
      el.remove();
    }, 3600);
  }

  function showAlert(el, msg) {
    if (!msg) {
      el.textContent = '';
      el.classList.add('hidden');
    } else {
      el.textContent = msg;
      el.classList.remove('hidden');
    }
  }

  // API client
  async function api(path, options = {}) {
    const headers = { ...(options.headers || {}) };
    if (options.body !== undefined) {
      headers['Content-Type'] = 'application/json';
    }
    if (state.token) {
      headers['Authorization'] = `Bearer ${state.token}`;
    }

    const res = await fetch(path, {
      method: options.method || 'GET',
      headers,
      body: options.body !== undefined ? JSON.stringify(options.body) : undefined
    });

    let data = {};
    try {
      data = await res.json();
    } catch (_) {
      data = {};
    }

    if (res.status === 401 && path !== '/api/login') {
      handleForceLogout(data.error || 'Session expired. Please sign in again.');
      throw new Error(data.error || 'Unauthorized');
    }

    if (!res.ok || data.ok === false) {
      throw new Error(data.error || `Request failed (${res.status})`);
    }
    return data;
  }

  // Auth Flow
  function showLoginView() {
    appShell.classList.add('hidden');
    loginView.classList.remove('hidden');
    loginPassword.value = '';
  }

  function showDashboardView() {
    loginView.classList.add('hidden');
    appShell.classList.remove('hidden');
    if (state.user) {
      document.getElementById('user-fullname').textContent = state.user.full_name || 'Librarian';
      document.getElementById('user-username').textContent = `@${state.user.username}`;
      document.getElementById('user-avatar').textContent = (state.user.full_name || state.user.username || 'L').charAt(0).toUpperCase();
    }
  }

  function handleForceLogout(msg) {
    state.token = '';
    state.user = null;
    localStorage.removeItem(TOKEN_KEY);
    closeAllModals();
    showLoginView();
    if (msg) showAlert(loginError, msg);
  }

  async function initSession() {
    if (!state.token) {
      showLoginView();
      return;
    }
    try {
      const data = await api('/api/me');
      state.user = data.user;
      showDashboardView();
      await refreshAll();
    } catch (_) {
      showLoginView();
    }
  }

  togglePasswordBtn.addEventListener('click', () => {
    const isPass = loginPassword.type === 'password';
    loginPassword.type = isPass ? 'text' : 'password';
    togglePasswordBtn.textContent = isPass ? 'Hide' : 'Show';
  });

  fillDemoBtn.addEventListener('click', () => {
    loginUsername.value = 'admin';
    loginPassword.value = 'admin123';
    showAlert(loginError, '');
  });

  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    showAlert(loginError, '');
    const username = loginUsername.value.trim();
    const password = loginPassword.value;
    if (!username || !password) {
      showAlert(loginError, 'Please enter both username and password.');
      return;
    }
    const submitBtn = document.getElementById('login-submit');
    submitBtn.disabled = true;
    submitBtn.textContent = 'Signing in...';
    try {
      const data = await api('/api/login', {
        method: 'POST',
        body: { username, password }
      });
      state.token = data.user.token;
      state.user = data.user;
      localStorage.setItem(TOKEN_KEY, state.token);
      showDashboardView();
      showToast(`Welcome back, ${state.user.full_name}!`);
      await refreshAll();
    } catch (err) {
      showAlert(loginError, err.message);
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Sign In';
    }
  });

  logoutBtn.addEventListener('click', async () => {
    try {
      await api('/api/logout', { method: 'POST' });
    } catch (_) {}
    handleForceLogout('');
    showToast('Signed out successfully.');
  });

  // Navigation & Responsive Sidebar
  function openSidebar() {
    sidebar.classList.add('open');
    sidebarBackdrop.classList.remove('hidden');
  }

  function closeSidebar() {
    sidebar.classList.remove('open');
    sidebarBackdrop.classList.add('hidden');
  }

  openSidebarBtn.addEventListener('click', openSidebar);
  closeSidebarBtn.addEventListener('click', closeSidebar);
  sidebarBackdrop.addEventListener('click', closeSidebar);

  function switchModule(moduleName) {
    state.activeModule = moduleName;
    document.querySelectorAll('.nav-item').forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.module === moduleName);
    });
    document.querySelectorAll('.module-panel').forEach((panel) => {
      panel.classList.toggle('hidden', panel.id !== `module-${moduleName}`);
    });
    const meta = MODULE_META[moduleName];
    moduleTitle.textContent = meta.title;
    moduleSubtitle.textContent = meta.subtitle;
    closeSidebar();

    if (moduleName === 'books') loadBooks();
    if (moduleName === 'students') loadStudents();
    if (moduleName === 'issues') loadIssues();
  }

  document.querySelectorAll('.nav-item').forEach((btn) => {
    btn.addEventListener('click', () => switchModule(btn.dataset.module));
  });

  // Modal helpers
  function openModal(id) {
    document.getElementById(id).classList.remove('hidden');
  }

  function closeModal(id) {
    document.getElementById(id).classList.add('hidden');
  }

  function closeAllModals() {
    document.querySelectorAll('.modal').forEach((m) => m.classList.add('hidden'));
  }

  document.querySelectorAll('[data-close-modal]').forEach((btn) => {
    btn.addEventListener('click', () => closeModal(btn.dataset.closeModal));
  });

  document.querySelectorAll('.modal').forEach((modal) => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.classList.add('hidden');
    });
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeAllModals();
      closeSidebar();
    }
  });

  // Load Stats & Data
  async function loadStats() {
    try {
      const data = await api('/api/stats');
      const s = data.stats;
      document.getElementById('stat-total-titles').textContent = s.total_titles;
      document.getElementById('stat-available-titles').textContent = s.available_titles;
      document.getElementById('stat-unavailable-titles').textContent = s.unavailable_titles;
      document.getElementById('stat-available-copies').textContent = s.available_copies;
      document.getElementById('stat-total-copies').textContent = s.total_copies;
      document.getElementById('stat-total-students').textContent = s.total_students;
      document.getElementById('stat-active-issued').textContent = s.active_issued;
      document.getElementById('stat-overdue-count').textContent = s.overdue_count;
      document.getElementById('stat-fines-collected').textContent = formatMoney(s.total_fines_collected);
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  async function refreshAll() {
    await Promise.all([loadStats(), loadBooks(), loadStudents(), loadIssues()]);
  }

  // =========================================================================
  // Module 1: Book Management
  // =========================================================================
  async function loadBooks() {
    const params = new URLSearchParams();
    if (state.bookQuery) params.set('q', state.bookQuery);
    if (state.bookFilter && state.bookFilter !== 'all') params.set('availability', state.bookFilter);

    try {
      const data = await api(`/api/books?${params.toString()}`);
      state.books = data.books || [];
      renderBooks();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  function renderBooks() {
    const tbody = document.getElementById('books-tbody');
    const empty = document.getElementById('books-empty');
    if (state.books.length === 0) {
      tbody.innerHTML = '';
      empty.classList.remove('hidden');
      return;
    }
    empty.classList.add('hidden');
    tbody.innerHTML = state.books.map((b) => {
      const isAvail = b.available_copies > 0;
      const badgeClass = isAvail ? 'badge-success' : 'badge-danger';
      return `
        <tr>
          <td class="mono">${escapeHtml(b.book_id)}</td>
          <td class="cell-primary">${escapeHtml(b.title)}</td>
          <td>${escapeHtml(b.author)}</td>
          <td>${escapeHtml(b.category)}</td>
          <td><strong>${b.available_copies}</strong> / ${b.total_copies}</td>
          <td><span class="badge ${badgeClass}">${escapeHtml(b.availability)}</span></td>
          <td>
            <div class="actions-cell">
              <button type="button" class="btn btn-secondary btn-sm" data-edit-book="${escapeHtml(b.book_id)}">Edit</button>
              <button type="button" class="btn btn-danger btn-sm" data-delete-book="${escapeHtml(b.book_id)}">Delete</button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  let bookSearchTimer;
  document.getElementById('book-search').addEventListener('input', (e) => {
    state.bookQuery = e.target.value.trim();
    clearTimeout(bookSearchTimer);
    bookSearchTimer = setTimeout(loadBooks, 200);
  });

  document.querySelectorAll('[data-book-filter]').forEach((pill) => {
    pill.addEventListener('click', () => {
      state.bookFilter = pill.dataset.bookFilter;
      document.querySelectorAll('[data-book-filter]').forEach((p) => p.classList.toggle('active', p === pill));
      loadBooks();
    });
  });

  document.getElementById('add-book-btn').addEventListener('click', () => {
    state.editingBookId = null;
    document.getElementById('book-modal-title').textContent = 'Add New Book';
    document.getElementById('book-save-btn').textContent = 'Add Book';
    const idInput = document.getElementById('book-id-input');
    idInput.value = '';
    idInput.disabled = false;
    document.getElementById('book-title-input').value = '';
    document.getElementById('book-author-input').value = '';
    document.getElementById('book-category-input').value = 'General';
    document.getElementById('book-copies-input').value = '1';
    showAlert(document.getElementById('book-form-error'), '');
    openModal('book-modal');
    idInput.focus();
  });

  document.getElementById('books-tbody').addEventListener('click', (e) => {
    const editBtn = e.target.closest('[data-edit-book]');
    if (editBtn) {
      const book = state.books.find((b) => b.book_id === editBtn.dataset.editBook);
      if (!book) return;
      state.editingBookId = book.book_id;
      document.getElementById('book-modal-title').textContent = 'Update Book Details';
      document.getElementById('book-save-btn').textContent = 'Update Book';
      const idInput = document.getElementById('book-id-input');
      idInput.value = book.book_id;
      idInput.disabled = true;
      document.getElementById('book-title-input').value = book.title;
      document.getElementById('book-author-input').value = book.author;
      document.getElementById('book-category-input').value = book.category;
      document.getElementById('book-copies-input').value = book.total_copies;
      showAlert(document.getElementById('book-form-error'), '');
      openModal('book-modal');
      return;
    }

    const delBtn = e.target.closest('[data-delete-book]');
    if (delBtn) {
      const book = state.books.find((b) => b.book_id === delBtn.dataset.deleteBook);
      if (!book) return;
      openDeleteConfirm(
        `Delete book "${book.title}" (${book.book_id})? This removes the book record from the database.`,
        async () => {
          await api(`/api/books/${encodeURIComponent(book.book_id)}`, { method: 'DELETE' });
          showToast('Book deleted successfully.');
          await refreshAll();
        }
      );
    }
  });

  document.getElementById('book-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const errEl = document.getElementById('book-form-error');
    showAlert(errEl, '');

    const bookId = document.getElementById('book-id-input').value.trim();
    const title = document.getElementById('book-title-input').value.trim();
    const author = document.getElementById('book-author-input').value.trim();
    const category = document.getElementById('book-category-input').value.trim() || 'General';
    const totalCopies = Number(document.getElementById('book-copies-input').value);

    if (!state.editingBookId && !/^[A-Za-z0-9][A-Za-z0-9_-]{1,39}$/.test(bookId)) {
      showAlert(errEl, 'Book ID must be 2–40 characters (letters, numbers, hyphens, underscores).');
      return;
    }
    if (!title || !author) {
      showAlert(errEl, 'Book title and author are required.');
      return;
    }
    if (!Number.isInteger(totalCopies) || totalCopies < 1) {
      showAlert(errEl, 'Total copies must be a whole number of at least 1.');
      return;
    }

    const saveBtn = document.getElementById('book-save-btn');
    saveBtn.disabled = true;
    try {
      if (state.editingBookId) {
        const res = await api(`/api/books/${encodeURIComponent(state.editingBookId)}`, {
          method: 'PUT',
          body: { title, author, category, total_copies: totalCopies }
        });
        showToast(res.message || 'Book updated.');
      } else {
        const res = await api('/api/books', {
          method: 'POST',
          body: { book_id: bookId, title, author, category, total_copies: totalCopies }
        });
        showToast(res.message || 'Book added.');
      }
      closeModal('book-modal');
      await refreshAll();
    } catch (err) {
      showAlert(errEl, err.message);
    } finally {
      saveBtn.disabled = false;
    }
  });

  // =========================================================================
  // Module 2: Student Management
  // =========================================================================
  async function loadStudents() {
    const params = new URLSearchParams();
    if (state.studentQuery) params.set('q', state.studentQuery);
    try {
      const data = await api(`/api/students?${params.toString()}`);
      state.students = data.students || [];
      renderStudents();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  function renderStudents() {
    const tbody = document.getElementById('students-tbody');
    const empty = document.getElementById('students-empty');
    if (state.students.length === 0) {
      tbody.innerHTML = '';
      empty.classList.remove('hidden');
      return;
    }
    empty.classList.add('hidden');
    tbody.innerHTML = state.students.map((s) => `
      <tr>
        <td class="mono">${escapeHtml(s.student_id)}</td>
        <td class="cell-primary">${escapeHtml(s.name)}</td>
        <td>${escapeHtml(s.department)}</td>
        <td class="mono">${escapeHtml(s.contact_number)}</td>
        <td><span class="badge ${s.active_issues > 0 ? 'badge-info' : 'badge-success'}">${s.active_issues} issued</span></td>
        <td>
          <div class="actions-cell">
            <button type="button" class="btn btn-secondary btn-sm" data-edit-student="${escapeHtml(s.student_id)}">Edit</button>
            <button type="button" class="btn btn-danger btn-sm" data-delete-student="${escapeHtml(s.student_id)}">Delete</button>
          </div>
        </td>
      </tr>
    `).join('');
  }

  let studentSearchTimer;
  document.getElementById('student-search').addEventListener('input', (e) => {
    state.studentQuery = e.target.value.trim();
    clearTimeout(studentSearchTimer);
    studentSearchTimer = setTimeout(loadStudents, 200);
  });

  document.getElementById('add-student-btn').addEventListener('click', () => {
    state.editingStudentId = null;
    document.getElementById('student-modal-title').textContent = 'Register New Student';
    document.getElementById('student-save-btn').textContent = 'Register Student';
    const idInput = document.getElementById('student-id-input');
    idInput.value = '';
    idInput.disabled = false;
    document.getElementById('student-name-input').value = '';
    document.getElementById('student-dept-input').value = '';
    document.getElementById('student-contact-input').value = '';
    showAlert(document.getElementById('student-form-error'), '');
    openModal('student-modal');
    idInput.focus();
  });

  document.getElementById('students-tbody').addEventListener('click', (e) => {
    const editBtn = e.target.closest('[data-edit-student]');
    if (editBtn) {
      const student = state.students.find((s) => s.student_id === editBtn.dataset.editStudent);
      if (!student) return;
      state.editingStudentId = student.student_id;
      document.getElementById('student-modal-title').textContent = 'Update Student Information';
      document.getElementById('student-save-btn').textContent = 'Update Student';
      const idInput = document.getElementById('student-id-input');
      idInput.value = student.student_id;
      idInput.disabled = true;
      document.getElementById('student-name-input').value = student.name;
      document.getElementById('student-dept-input').value = student.department;
      document.getElementById('student-contact-input').value = student.contact_number;
      showAlert(document.getElementById('student-form-error'), '');
      openModal('student-modal');
      return;
    }

    const delBtn = e.target.closest('[data-delete-student]');
    if (delBtn) {
      const student = state.students.find((s) => s.student_id === delBtn.dataset.deleteStudent);
      if (!student) return;
      openDeleteConfirm(
        `Delete student "${student.name}" (${student.student_id})? This removes the student record from the database.`,
        async () => {
          await api(`/api/students/${encodeURIComponent(student.student_id)}`, { method: 'DELETE' });
          showToast('Student record deleted.');
          await refreshAll();
        }
      );
    }
  });

  document.getElementById('student-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const errEl = document.getElementById('student-form-error');
    showAlert(errEl, '');

    const studentId = document.getElementById('student-id-input').value.trim();
    const name = document.getElementById('student-name-input').value.trim();
    const department = document.getElementById('student-dept-input').value.trim();
    const contact = document.getElementById('student-contact-input').value.trim();

    if (!state.editingStudentId && !/^[A-Za-z0-9][A-Za-z0-9_-]{1,39}$/.test(studentId)) {
      showAlert(errEl, 'Student ID must be 2–40 characters (letters, numbers, hyphens, underscores).');
      return;
    }
    if (!name || !department) {
      showAlert(errEl, 'Student name and department are required.');
      return;
    }
    const digitCount = (contact.match(/\d/g) || []).length;
    if (!/^[0-9+\-\s()]{7,30}$/.test(contact) || digitCount < 7 || digitCount > 15) {
      showAlert(errEl, 'Enter a valid contact number (7–15 digits).');
      return;
    }

    const saveBtn = document.getElementById('student-save-btn');
    saveBtn.disabled = true;
    try {
      if (state.editingStudentId) {
        const res = await api(`/api/students/${encodeURIComponent(state.editingStudentId)}`, {
          method: 'PUT',
          body: { name, department, contact_number: contact }
        });
        showToast(res.message || 'Student updated.');
      } else {
        const res = await api('/api/students', {
          method: 'POST',
          body: { student_id: studentId, name, department, contact_number: contact }
        });
        showToast(res.message || 'Student registered.');
      }
      closeModal('student-modal');
      await refreshAll();
    } catch (err) {
      showAlert(errEl, err.message);
    } finally {
      saveBtn.disabled = false;
    }
  });

  // =========================================================================
  // Module 3: Book Issue & Return Management
  // =========================================================================
  async function loadIssues() {
    const params = new URLSearchParams();
    if (state.issueQuery) params.set('q', state.issueQuery);
    if (state.issueFilter && state.issueFilter !== 'all') params.set('status', state.issueFilter);
    try {
      const data = await api(`/api/issues?${params.toString()}`);
      state.issues = data.issues || [];
      renderIssues();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  function renderIssues() {
    const tbody = document.getElementById('issues-tbody');
    const empty = document.getElementById('issues-empty');
    if (state.issues.length === 0) {
      tbody.innerHTML = '';
      empty.classList.remove('hidden');
      return;
    }
    empty.classList.add('hidden');
    tbody.innerHTML = state.issues.map((item) => {
      let badgeHtml = '<span class="badge badge-info">Issued</span>';
      if (item.status === 'RETURNED') {
        badgeHtml = '<span class="badge badge-success">Returned</span>';
      } else if (item.is_overdue) {
        badgeHtml = `<span class="badge badge-danger">Overdue (${item.days_late}d)</span>`;
      }

      const fineValue = item.status === 'RETURNED' ? item.fine_amount : item.estimated_fine;
      const fineText = Number(fineValue) > 0
        ? `<span class="${item.status === 'RETURNED' ? '' : 'text-danger'}">$${formatMoney(fineValue)}</span>`
        : '$0.00';

      const returnBtn = item.status === 'ISSUED'
        ? `<button type="button" class="btn btn-success btn-sm" data-return-issue="${item.issue_id}">Return</button>`
        : '';

      return `
        <tr>
          <td class="mono">#${item.issue_id}</td>
          <td>
            <div class="cell-primary">${escapeHtml(item.book_title)}</div>
            <div class="cell-sub mono">${escapeHtml(item.book_id)}</div>
          </td>
          <td>
            <div class="cell-primary">${escapeHtml(item.student_name)}</div>
            <div class="cell-sub mono">${escapeHtml(item.student_id)} &middot; ${escapeHtml(item.student_department)}</div>
          </td>
          <td class="mono">${escapeHtml(item.issue_date)}</td>
          <td class="mono">${escapeHtml(item.due_date)}</td>
          <td class="mono">${item.return_date ? escapeHtml(item.return_date) : '<span class="muted">Not returned</span>'}</td>
          <td>${badgeHtml}</td>
          <td>${fineText}</td>
          <td>
            <div class="actions-cell">
              ${returnBtn}
              <button type="button" class="btn btn-secondary btn-sm" data-edit-issue="${item.issue_id}">Update</button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  let issueSearchTimer;
  document.getElementById('issue-search').addEventListener('input', (e) => {
    state.issueQuery = e.target.value.trim();
    clearTimeout(issueSearchTimer);
    issueSearchTimer = setTimeout(loadIssues, 200);
  });

  document.querySelectorAll('[data-issue-filter]').forEach((pill) => {
    pill.addEventListener('click', () => {
      state.issueFilter = pill.dataset.issueFilter;
      document.querySelectorAll('[data-issue-filter]').forEach((p) => p.classList.toggle('active', p === pill));
      loadIssues();
    });
  });

  document.getElementById('issue-book-btn').addEventListener('click', async () => {
    showAlert(document.getElementById('issue-form-error'), '');
    try {
      const [studentsRes, booksRes] = await Promise.all([
        api('/api/students'),
        api('/api/books?availability=available')
      ]);
      const studentSel = document.getElementById('issue-student-select');
      const bookSel = document.getElementById('issue-book-select');

      const students = studentsRes.students || [];
      const availBooks = booksRes.books || [];

      if (students.length === 0) {
        studentSel.innerHTML = '<option value="">No registered students found</option>';
      } else {
        studentSel.innerHTML = '<option value="">-- Select Student --</option>' +
          students.map((s) => `<option value="${escapeHtml(s.student_id)}">${escapeHtml(s.student_id)} — ${escapeHtml(s.name)} (${escapeHtml(s.department)})</option>`).join('');
      }

      if (availBooks.length === 0) {
        bookSel.innerHTML = '<option value="">No available books in stock</option>';
      } else {
        bookSel.innerHTML = '<option value="">-- Select Available Book --</option>' +
          availBooks.map((b) => `<option value="${escapeHtml(b.book_id)}">${escapeHtml(b.book_id)} — ${escapeHtml(b.title)} (${b.available_copies} avail.)</option>`).join('');
      }

      const today = todayIso();
      document.getElementById('issue-date-input').value = today;
      document.getElementById('issue-due-input').value = addDaysIso(today, 14);
      document.getElementById('issue-rate-input').value = '2.00';
      document.getElementById('issue-notes-input').value = '';
      openModal('issue-modal');
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  document.getElementById('issue-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const errEl = document.getElementById('issue-form-error');
    showAlert(errEl, '');

    const studentId = document.getElementById('issue-student-select').value;
    const bookId = document.getElementById('issue-book-select').value;
    const issueDate = document.getElementById('issue-date-input').value;
    const dueDate = document.getElementById('issue-due-input').value;
    const finePerDay = Number(document.getElementById('issue-rate-input').value);
    const notes = document.getElementById('issue-notes-input').value.trim();

    if (!studentId) {
      showAlert(errEl, 'Please select a registered student.');
      return;
    }
    if (!bookId) {
      showAlert(errEl, 'Please select an available book.');
      return;
    }
    if (!issueDate || !dueDate) {
      showAlert(errEl, 'Issue date and expected return date are required.');
      return;
    }
    if (dueDate < issueDate) {
      showAlert(errEl, 'Expected return date cannot be earlier than the issue date.');
      return;
    }
    if (Number.isNaN(finePerDay) || finePerDay < 0) {
      showAlert(errEl, 'Daily fine rate must be 0 or greater.');
      return;
    }

    const saveBtn = document.getElementById('issue-save-btn');
    saveBtn.disabled = true;
    try {
      const res = await api('/api/issues', {
        method: 'POST',
        body: {
          student_id: studentId,
          book_id: bookId,
          issue_date: issueDate,
          due_date: dueDate,
          fine_per_day: finePerDay,
          notes
        }
      });
      closeModal('issue-modal');
      showToast(res.message || 'Book issued successfully.');
      await refreshAll();
    } catch (err) {
      showAlert(errEl, err.message);
    } finally {
      saveBtn.disabled = false;
    }
  });

  function updateReturnFinePreview() {
    const item = state.returningIssue;
    if (!item) return;
    const returnDate = document.getElementById('return-date-input').value;
    const previewEl = document.getElementById('return-fine-preview');
    if (!returnDate) {
      previewEl.textContent = '$0.00';
      previewEl.classList.remove('late');
      return;
    }
    const daysLate = Math.max(0, diffDays(item.due_date, returnDate));
    const fine = daysLate * Number(item.fine_per_day || 0);
    if (daysLate > 0) {
      previewEl.textContent = `$${formatMoney(fine)} (${daysLate} day${daysLate === 1 ? '' : 's'} late × $${formatMoney(item.fine_per_day)}/day)`;
      previewEl.classList.add('late');
    } else {
      previewEl.textContent = '$0.00 (Returned on time)';
      previewEl.classList.remove('late');
    }
  }

  document.getElementById('return-date-input').addEventListener('change', updateReturnFinePreview);

  function recalculateEditFine() {
    const due = document.getElementById('edit-due-input').value;
    const ret = document.getElementById('edit-return-input').value;
    const rate = Number(document.getElementById('edit-rate-input').value || 0);
    const fineInput = document.getElementById('edit-fine-input');
    if (due && ret) {
      const late = Math.max(0, diffDays(due, ret));
      fineInput.value = formatMoney(late * Math.max(0, rate));
    }
  }

  ['edit-due-input', 'edit-return-input', 'edit-rate-input'].forEach((id) => {
    document.getElementById(id).addEventListener('change', recalculateEditFine);
  });

  document.getElementById('issues-tbody').addEventListener('click', (e) => {
    const retBtn = e.target.closest('[data-return-issue]');
    if (retBtn) {
      const issue = state.issues.find((i) => i.issue_id === Number(retBtn.dataset.returnIssue));
      if (!issue) return;
      state.returningIssue = issue;
      showAlert(document.getElementById('return-form-error'), '');
      document.getElementById('return-summary').innerHTML = `
        <div><strong>Book:</strong> ${escapeHtml(issue.book_title)} (<span class="mono">${escapeHtml(issue.book_id)}</span>)</div>
        <div><strong>Student:</strong> ${escapeHtml(issue.student_name)} (<span class="mono">${escapeHtml(issue.student_id)}</span>)</div>
        <div><strong>Issued:</strong> ${escapeHtml(issue.issue_date)} &middot; <strong>Due:</strong> ${escapeHtml(issue.due_date)}</div>
      `;
      document.getElementById('return-date-input').value = todayIso();
      document.getElementById('return-notes-input').value = issue.notes || '';
      updateReturnFinePreview();
      openModal('return-modal');
      return;
    }

    const editBtn = e.target.closest('[data-edit-issue]');
    if (editBtn) {
      const issue = state.issues.find((i) => i.issue_id === Number(editBtn.dataset.editIssue));
      if (!issue) return;
      state.editingIssue = issue;
      showAlert(document.getElementById('edit-issue-error'), '');
      document.getElementById('edit-issue-summary').innerHTML = `
        <div><strong>Record #${issue.issue_id}</strong> &middot; Status: <strong>${escapeHtml(issue.status)}</strong></div>
        <div><strong>Book:</strong> ${escapeHtml(issue.book_title)} (${escapeHtml(issue.book_id)})</div>
        <div><strong>Student:</strong> ${escapeHtml(issue.student_name)} (${escapeHtml(issue.student_id)})</div>
      `;
      document.getElementById('edit-due-input').value = issue.due_date;
      document.getElementById('edit-return-input').value = issue.return_date || '';
      document.getElementById('edit-rate-input').value = formatMoney(issue.fine_per_day);
      document.getElementById('edit-fine-input').value = issue.status === 'RETURNED' ? formatMoney(issue.fine_amount) : '';
      document.getElementById('edit-notes-input').value = issue.notes || '';
      openModal('edit-issue-modal');
    }
  });

  document.getElementById('return-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const issue = state.returningIssue;
    if (!issue) return;
    const errEl = document.getElementById('return-form-error');
    showAlert(errEl, '');

    const returnDate = document.getElementById('return-date-input').value;
    const notes = document.getElementById('return-notes-input').value.trim();

    if (!returnDate) {
      showAlert(errEl, 'Actual return date is required.');
      return;
    }
    if (returnDate < issue.issue_date) {
      showAlert(errEl, `Return date cannot be earlier than issue date (${issue.issue_date}).`);
      return;
    }

    const saveBtn = document.getElementById('return-save-btn');
    saveBtn.disabled = true;
    try {
      const res = await api(`/api/issues/${issue.issue_id}/return`, {
        method: 'POST',
        body: { return_date: returnDate, notes }
      });
      closeModal('return-modal');
      const fine = Number(res.issue?.fine_amount || 0);
      showToast(fine > 0
        ? `Book returned. Late fine recorded: $${formatMoney(fine)}.`
        : 'Book returned and marked available.');
      await refreshAll();
    } catch (err) {
      showAlert(errEl, err.message);
    } finally {
      saveBtn.disabled = false;
    }
  });

  document.getElementById('edit-issue-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const issue = state.editingIssue;
    if (!issue) return;
    const errEl = document.getElementById('edit-issue-error');
    showAlert(errEl, '');

    const dueDate = document.getElementById('edit-due-input').value;
    const returnDate = document.getElementById('edit-return-input').value;
    const finePerDay = Number(document.getElementById('edit-rate-input').value);
    const fineRaw = document.getElementById('edit-fine-input').value.trim();
    const notes = document.getElementById('edit-notes-input').value.trim();

    if (!dueDate) {
      showAlert(errEl, 'Expected return date is required.');
      return;
    }
    if (dueDate < issue.issue_date) {
      showAlert(errEl, `Expected return date cannot be earlier than issue date (${issue.issue_date}).`);
      return;
    }
    if (issue.status === 'RETURNED' && !returnDate) {
      showAlert(errEl, 'Actual return date is required for a returned record.');
      return;
    }
    if (returnDate && returnDate < issue.issue_date) {
      showAlert(errEl, `Actual return date cannot be earlier than issue date (${issue.issue_date}).`);
      return;
    }
    if (Number.isNaN(finePerDay) || finePerDay < 0) {
      showAlert(errEl, 'Daily fine rate must be 0 or greater.');
      return;
    }

    const payload = {
      due_date: dueDate,
      return_date: returnDate || null,
      fine_per_day: finePerDay,
      notes
    };
    if (fineRaw !== '') {
      const parsedFine = Number(fineRaw);
      if (Number.isNaN(parsedFine) || parsedFine < 0) {
        showAlert(errEl, 'Fine amount must be 0 or greater.');
        return;
      }
      payload.fine_amount = parsedFine;
    }

    const saveBtn = document.getElementById('edit-issue-save-btn');
    saveBtn.disabled = true;
    try {
      const res = await api(`/api/issues/${issue.issue_id}`, {
        method: 'PUT',
        body: payload
      });
      closeModal('edit-issue-modal');
      showToast(res.message || 'Return information updated.');
      await refreshAll();
    } catch (err) {
      showAlert(errEl, err.message);
    } finally {
      saveBtn.disabled = false;
    }
  });

  // Delete confirmation dialog
  function openDeleteConfirm(message, onConfirm) {
    state.pendingDelete = onConfirm;
    document.getElementById('confirm-message').textContent = message;
    showAlert(document.getElementById('confirm-error'), '');
    openModal('confirm-modal');
  }

  document.getElementById('confirm-delete-btn').addEventListener('click', async () => {
    if (!state.pendingDelete) return;
    const btn = document.getElementById('confirm-delete-btn');
    const errEl = document.getElementById('confirm-error');
    showAlert(errEl, '');
    btn.disabled = true;
    try {
      await state.pendingDelete();
      closeModal('confirm-modal');
      state.pendingDelete = null;
    } catch (err) {
      showAlert(errEl, err.message);
    } finally {
      btn.disabled = false;
    }
  });

  // Boot
  initSession();
})();
