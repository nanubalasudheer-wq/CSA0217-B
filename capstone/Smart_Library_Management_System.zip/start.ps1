param(
    [int]$Port = 5050
)

$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

if (-not (Test-Path 'out')) {
    New-Item -ItemType Directory -Path 'out' | Out-Null
}

Write-Host 'Compiling Smart Library Management System...' -ForegroundColor Cyan
javac -cp 'lib/h2-2.3.232.jar' -d out src/com/library/*.java
if ($LASTEXITCODE -ne 0) {
    throw 'Compilation failed. Ensure Java JDK is installed and on PATH.'
}

Write-Host "Starting server at http://127.0.0.1:$Port" -ForegroundColor Green
Write-Host 'Default login: admin / admin123' -ForegroundColor Yellow
java -cp 'out;lib/h2-2.3.232.jar' com.library.LibraryServer $Port
